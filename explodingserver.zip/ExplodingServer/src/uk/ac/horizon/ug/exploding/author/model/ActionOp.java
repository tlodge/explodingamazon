package uk.ac.horizon.ug.exploding.author.model;

public class ActionOp
{
	public int minimum;
	
	public int maximum;
}
