package uk.ac.horizon.ug.exploding.author.model;

public class BrainsOp
{
	public int minimum;
	
	public int maximum;
}
