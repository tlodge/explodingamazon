package uk.ac.horizon.ug.exploding.author.model;

public class Coordinate
{
	public Double latitude;
	
	public Double longitude;
	
	public Double elevation;
}
