package uk.ac.horizon.ug.exploding.author.model;

public class HealthOp
{
	public int minimum;
	
	public int maximum;
}
