package uk.ac.horizon.ug.exploding.author.model;

public class IndexList
{
	public String ref;
	
	public AttributeSet attributeSet;
}
