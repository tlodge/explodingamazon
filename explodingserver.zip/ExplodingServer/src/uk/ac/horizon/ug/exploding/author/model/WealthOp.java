package uk.ac.horizon.ug.exploding.author.model;

public class WealthOp
{
	public int minimum;
	
	public int maximum;
}
