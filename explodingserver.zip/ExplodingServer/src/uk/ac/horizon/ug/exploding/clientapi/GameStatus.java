package uk.ac.horizon.ug.exploding.clientapi;
/** Game status */
public enum GameStatus {
	UNKNOWN, // unknown!
	NOT_STARTED, 
	ACTIVE, // running
	ENDING, // final phase?!
	ENDED
}
