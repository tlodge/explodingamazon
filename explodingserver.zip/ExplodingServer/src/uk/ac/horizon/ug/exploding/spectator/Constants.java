package uk.ac.horizon.ug.exploding.spectator;

public class Constants
{
	public static final String ENCODING_PARAMETER_NAME = "encoding";
	public static final String JSON_ENCODING = "json";
	public static final String OBJECT_MODEL_NAME = "object";
}
